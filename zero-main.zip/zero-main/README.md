pkg update

pkg upgrade

pkg install git

pkg install python

pkg install python2

pip install requests

pip install mechanize

pip install bs4

rm -rf saqib

git https://github.com/happyboysaqib/zero.git

cd zero

python zero.py
